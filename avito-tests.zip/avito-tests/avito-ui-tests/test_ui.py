import time
import pytest
from playwright.sync_api import Page, expect


SELECTORS = {
    # Фильтр цен
    "price_min": 'input[placeholder="От"]',
    "price_max": 'input[placeholder="До"]',
    "reset_filter": 'button:has-text("Сбросить"), .filter-reset-btn',
    # Категория
    "category_select": 'select[name="category"], select[id*="category"], .category-select',
    # Карточки объявлений
    "item_card": '.item-card, .listing-item, [data-testid="item"], .ad-card',
    "price": '.item-card .price, .listing-price, [data-testid="price"], .price-tag',
    "category_badge": '.category-badge, .item-category, [data-testid="category"]',
    "urgent_badge": '.badge-urgent, .urgent-tag, [data-testid="urgent"]',
    # Сообщения
    "error_message": '.error-message, [role="alert"], .alert-danger, .validation-error',
    "no_results": '.no-results, .empty-state, .empty-list, :has-text("не найдено")',
}


def get_prices(page: Page) -> list:
    prices = []
    for card in page.locator(SELECTORS["price"]).all():
        text = card.text_content()
        price = int("".join(filter(str.isdigit, text)))
        prices.append(price)
    return prices


def count_cards(page: Page) -> int:
    return page.locator(SELECTORS["item_card"]).count()


#  ФИЛЬТР «ДИАПАЗОН ЦЕН»


class TestPriceFilter:
    @pytest.mark.xfail(reason="BUG-UI-001: Фильтр диапазона цен не фильтрует объявления")
    def test_tc_101_valid_price_range(self, page: Page, ui_base_url: str):
        page.goto(f"{ui_base_url}/")
        expect(page).to_have_title("avito-test", timeout=10000)
        page.locator(SELECTORS["price_min"]).fill("5000")
        page.locator(SELECTORS["price_max"]).fill("15000")
        page.wait_for_load_state("networkidle")

        prices = get_prices(page)
        assert len(prices) > 0, "Нет объявлений"

        out_of_range = [p for p in prices if not (5000 <= p <= 15000)]
        assert len(out_of_range) == 0, f"Найдены цены вне диапазона: {out_of_range}"

    def test_tc_102_min_price_only(self, page: Page, ui_base_url: str):
        page.goto(f"{ui_base_url}/")

        page.locator(SELECTORS["price_min"]).fill("80000")
        page.wait_for_load_state("networkidle")

        prices = get_prices(page)
        assert all(p >= 80000 for p in prices), f"Найдены цены меньше 80000: {[p for p in prices if p < 80000]}"

    def test_tc_103_max_price_only(self, page: Page, ui_base_url: str):
        page.goto(f"{ui_base_url}/")

        page.locator(SELECTORS["price_max"]).fill("15000")
        page.wait_for_load_state("networkidle")

        prices = get_prices(page)
        assert all(p <= 15000 for p in prices), f"Найдены цены больше 15000: {[p for p in prices if p > 15000]}"

    def test_tc_104_reset_filter(self, page: Page, ui_base_url: str):
        page.goto(f"{ui_base_url}/")

        page.locator(SELECTORS["price_min"]).fill("5000")
        page.wait_for_load_state("networkidle")
        filtered_count = count_cards(page)

        page.locator(SELECTORS["price_min"]).clear()
        page.locator(SELECTORS["price_max"]).clear()
        page.wait_for_load_state("networkidle")
        all_count = count_cards(page)

        assert all_count >= filtered_count, "После сброса объявлений стало меньше"

    def test_tc_105_invalid_price_range(self, page: Page, ui_base_url: str):
        """TC-105: Мин. цена > макс. цены"""
        page.goto(f"{ui_base_url}/")

        page.locator(SELECTORS["price_min"]).fill("15000")
        page.locator(SELECTORS["price_max"]).fill("5000")
        page.wait_for_load_state("networkidle")

        error = page.locator(SELECTORS["error_message"])
        no_results = page.locator(SELECTORS["no_results"])

        if error.count() > 0:
            expect(error).to_be_visible()
        elif no_results.count() > 0:
            expect(no_results).to_contain_text("не найдено", ignore_case=True)

    @pytest.mark.xfail(reason="BUG-002: Поле цены принимает отрицательные значения")
    def test_tc_106_negative_price(self, page: Page, ui_base_url: str):
        page.goto(f"{ui_base_url}/")

        page.locator(SELECTORS["price_min"]).fill("-100")
        page.wait_for_timeout(1000)

        actual_value = page.locator(SELECTORS["price_min"]).input_value()
        assert (
            actual_value == "" or actual_value == "0" or "-" not in actual_value
        ), f"Отрицательное значение не обработано: {actual_value}"

    def test_tc_107_equal_price_range(self, page: Page, ui_base_url: str):
        page.goto(f"{ui_base_url}/")

        page.locator(SELECTORS["price_min"]).fill("10000")
        page.locator(SELECTORS["price_max"]).fill("10000")
        page.wait_for_load_state("networkidle")

        prices = get_prices(page)
        if len(prices) > 0:
            assert all(p == 10000 for p in prices), f"Найдены цены != 10000: {prices}"
    @pytest.mark.xfail(reason="BUG-003: Поле цены не ограничивает длину ввода")
    def test_tc_108_max_length_validation(self, page: Page, ui_base_url: str):
        page.goto(f"{ui_base_url}/")

        long_value = "9" * 30
        page.locator(SELECTORS["price_min"]).fill(long_value)

        actual_min = page.locator(SELECTORS["price_min"]).input_value()
        assert len(actual_min) < 30, f"Поле принимает неограниченное количество цифр: {len(actual_min)}"

