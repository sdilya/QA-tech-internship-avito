import pytest
from playwright.sync_api import Page, BrowserContext


@pytest.fixture(scope="session")
def ui_base_url():
    return "https://cerulean-praline-8e5aa6.netlify.app"


@pytest.fixture
def desktop_context(context: BrowserContext):
    context.set_viewport_size({"width": 1920, "height": 1080})
    return context


@pytest.fixture
def mobile_context(context: BrowserContext):
    context.set_viewport_size({"width": 375, "height": 667})  # iPhone SE
    return context
