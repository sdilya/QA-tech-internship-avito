import requests
import uuid
import random
import time
import pytest
import allure


def generate_seller_id():
    return random.randint(111111, 999999)


def generate_unique_name(prefix="Test"):
    return f"{prefix}_{int(time.time() * 1000)}"


def create_item(payload, base_url):
    resp = requests.post(f"{base_url}/api/1/item", json=payload, timeout=30)
    data = resp.json()

    if "id" in data:
        item_id = data["id"]
    elif "status" in data:
        item_id = data["status"].split(" - ")[-1]
    else:
        item_id = None
    return resp, item_id


def delete_item(item_id, base_url):
    return requests.delete(f"{base_url}/api/2/item/{item_id}", timeout=15)


# POST /api/1/item


@allure.feature("Создание объявлений")
@allure.story("Позитивные сценарии")
@allure.title("TC-001: Успешное создание объявления")
@allure.description("Проверка успешного создания объявления с корректными данными")
@allure.severity(allure.severity_level.CRITICAL)
def test_tc_001_create_success(base_url):
    payload = {
        "sellerID": generate_seller_id(),
        "name": generate_unique_name("PlayStation5"),
        "price": 45000,
        "statistics": {"likes": 2, "viewCount": 1, "contacts": 10},
    }

    with allure.step("1. Подготовка тестовых данных"):
        allure.attach(str(payload), name="Тело запроса (JSON)", attachment_type=allure.attachment_type.JSON)

    with allure.step("2. Отправка POST-запроса на /api/1/item"):
        resp, item_id = create_item(payload, base_url)

    with allure.step("3. Проверка статуса ответа"):
        allure.attach(
            f"Ожидаемый статус: 200\nФактический статус: {resp.status_code}",
            name="Статус код",
            attachment_type=allure.attachment_type.TEXT,
        )
        assert resp.status_code == 200

    with allure.step("4. Проверка наличия ID в ответе"):
        allure.attach(f"ID объявления: {item_id}", name="Created Item ID", attachment_type=allure.attachment_type.TEXT)
        assert item_id is not None

    with allure.step("5. Проверка структуры ответа"):
        data = resp.json()
    assert "id" in data or "status" in data, "Ответ не содержит id или status"


@allure.feature("Создание объявлений")
@allure.story("Негативные сценарии")
@allure.title("TC-002: Создание объявления с пустым именем")
@allure.description("Проверка валидации")
@allure.severity(allure.severity_level.NORMAL)
def test_tc_002_empty_name(base_url):
    payload = {
        "sellerID": generate_seller_id(),
        "name": "",
        "price": 6000,
        "statistics": {"likes": 1, "viewCount": 1, "contacts": 2},
    }

    with allure.step("1. Подготовка данных с пустым name"):
        allure.attach(str(payload), name="Тело запроса (JSON)", attachment_type=allure.attachment_type.JSON)

    with allure.step("2. Отправка POST-запроса"):
        resp, _ = create_item(payload, base_url)

    with allure.step("3. Проверка статуса 400"):
        assert resp.status_code == 400


@allure.feature("Создание объявлений")
@allure.story("Баг")
@allure.title("TC-003: Создание объявления с отрицательной ценой")
@allure.severity(allure.severity_level.CRITICAL)
@pytest.mark.xfail(reason="BUG-001: API принимает отрицательную цену")
def test_tc_003_negative_price(base_url):
    payload = {
        "sellerID": generate_seller_id(),
        "name": generate_unique_name("Кукла"),
        "price": -100,
        "statistics": {"likes": 1, "viewCount": 1, "contacts": 2},
    }

    with allure.step("1. Подготовка данных с отрицательной ценой"):
        allure.attach(str(payload), name="Request Body", attachment_type=allure.attachment_type.JSON)

    with allure.step("2. Отправка POST-запроса на /api/1/item"):
        resp, _ = create_item(payload, base_url)

    with allure.step("3. Проверка статуса ответа"):
        allure.attach(
            f"Ожидаем: 400\nПолучаем: {resp.status_code}",
            name="Expected vs Actual",
            attachment_type=allure.attachment_type.TEXT,
        )
        assert resp.status_code == 400


@allure.feature("Создание объявлений")
@allure.story("Идемпотентность")
@allure.title("TC-004: Идемпотентность создания объявлений")
@allure.severity(allure.severity_level.NORMAL)
def test_tc_004_idempotency(base_url):
    payload = {
        "sellerID": generate_seller_id(),
        "name": generate_unique_name("Машинка"),
        "price": 200,
        "statistics": {"likes": 1, "viewCount": 1, "contacts": 2},
    }

    with allure.step("1. Первый запрос на создание"):
        resp1, id1 = create_item(payload, base_url)

    with allure.step("2. Второй запрос с теми же данными"):
        resp2, id2 = create_item(payload, base_url)

    with allure.step("3. Проверка: оба запроса успешны, но ID разные"):
        assert resp1.status_code == 200
        assert resp2.status_code == 200
        assert id1 != id2


@allure.feature("Создание объявлений")
@allure.story("Валидация типов")
@allure.title("TC-005: Создание объявления с неверным типом sellerID")
@allure.severity(allure.severity_level.NORMAL)
def test_tc_005_invalid_seller_type(base_url):
    payload = {
        "sellerID": "один",
        "name": generate_unique_name("Машинка"),
        "price": 200,
        "statistics": {"likes": 1, "viewCount": 1, "contacts": 2},
    }

    with allure.step("1. Подготовка данных с строковым sellerID"):
        allure.attach(str(payload), name="Тело запроса (JSON)", attachment_type=allure.attachment_type.JSON)

    with allure.step("2. Отправка POST-запроса"):
        resp, _ = create_item(payload, base_url)

    with allure.step("3. Проверка статуса 400"):
        assert resp.status_code == 400


# GET /api/1/item/{id}


@allure.feature("Получение объявлений")
@allure.story("Позитивные сценарии")
@allure.title("TC-101: Получение существующего объявления")
@allure.severity(allure.severity_level.CRITICAL)
@pytest.mark.e2e
def test_tc_101_get_existing_item(base_url):
    payload = {
        "sellerID": generate_seller_id(),
        "name": "Item",
        "price": 100,
        "statistics": {"likes": 1, "viewCount": 1, "contacts": 1},
    }

    with allure.step("1. Создание тестового объявления"):
        _, item_id = create_item(payload, base_url)
        allure.attach(str(item_id), name="Created Item ID", attachment_type=allure.attachment_type.TEXT)

    with allure.step("2. GET запрос по ID"):
        resp = requests.get(f"{base_url}/api/1/item/{item_id}", timeout=30)
        body = resp.json()

    with allure.step("3. Проверка ответа"):
        assert resp.status_code == 200
        assert isinstance(body, list) and len(body) > 0
        item = body[0]
        assert "createdAt" in item
        assert item["id"] == item_id
        assert item["sellerId"] == payload["sellerID"]
        assert item["name"] == payload["name"]
        assert item["price"] == payload["price"]
        assert item["statistics"] == payload["statistics"]


@allure.feature("Получение объявлений")
@allure.story("Негативные сценарии")
@allure.title("TC-102: Получение несуществующего объявления")
@allure.severity(allure.severity_level.NORMAL)
def test_tc_102_not_found(base_url):
    fake_id = str(uuid.uuid4())

    with allure.step(f"1. GET запрос по несуществующему ID: {fake_id}"):
        resp = requests.get(f"{base_url}/api/1/item/{fake_id}", timeout=30)

    with allure.step("2. Проверка статуса 404"):
        assert resp.status_code == 404


@allure.feature("Получение объявлений")
@allure.story("Валидация входных данных")
@allure.title("TC-103: Получение объявления с невалидным ID")
@allure.severity(allure.severity_level.NORMAL)
def test_tc_103_invalid_id(base_url):
    with allure.step("1. GET запрос с невалидным ID 'abc'"):
        resp = requests.get(f"{base_url}/api/1/item/abc", timeout=30)

    with allure.step("2. Проверка статуса 400"):
        assert resp.status_code == 400


@allure.feature("Получение объявлений")
@allure.story("Жизненный цикл")
@allure.title("TC-104: Получение удаленного объявления")
@allure.severity(allure.severity_level.CRITICAL)
@pytest.mark.e2e
def test_tc_104_deleted_item(base_url):
    payload = {
        "sellerID": generate_seller_id(),
        "name": "Temp",
        "price": 100,
        "statistics": {"likes": 1, "viewCount": 1, "contacts": 1},
    }

    with allure.step("1. Создание объявления"):
        _, item_id = create_item(payload, base_url)
        allure.attach(str(item_id), name="Item ID", attachment_type=allure.attachment_type.TEXT)

    with allure.step("2. Удаление объявления через DELETE /api/2/item/{id}"):
        delete_resp = delete_item(item_id, base_url)
        allure.attach(str(delete_resp.status_code), name="Delete Status", attachment_type=allure.attachment_type.TEXT)

    with allure.step("3. Проверка: объявление удалено (ожидаем 404)"):
        resp = requests.get(f"{base_url}/api/1/item/{item_id}", timeout=30)
        assert resp.status_code == 404


# GET /api/1/{sellerID}/item


@allure.feature("Получение объявлений продавца")
@allure.story("Позитивные сценарии")
@allure.title("TC-201: Успешное получение всех объявлений продавца")
@allure.severity(allure.severity_level.NORMAL)
def test_tc_201_get_items_by_seller(base_url):
    seller_id = generate_seller_id()
    payload = {
        "sellerID": seller_id,
        "name": "Item",
        "price": 100,
        "statistics": {"likes": 1, "viewCount": 1, "contacts": 1},
    }

    with allure.step(f"1. Создание объявления для sellerID={seller_id}"):
        create_item(payload, base_url)

    with allure.step(f"2. GET запрос на /api/1/{seller_id}/item"):
        resp = requests.get(f"{base_url}/api/1/{seller_id}/item", timeout=30)
        items = resp.json()

    with allure.step("3. Проверка: все объявления принадлежат этому продавцу"):
        assert resp.status_code == 200
        assert isinstance(items, list)
        for item in items:
            assert item["sellerId"] == seller_id


@allure.feature("Получение объявлений продавца")
@allure.story("Пустые результаты")
@allure.title("TC-202: Несуществующий продавец с sellerID=9999989")
@allure.severity(allure.severity_level.NORMAL)
def test_tc_202_no_items(base_url):
    with allure.step("1. GET запрос для несуществующего sellerID=9999989"):
        resp = requests.get(f"{base_url}/api/1/9999989/item", timeout=30)

    with allure.step("2. Проверка: статус 200 и пустой массив"):
        assert resp.status_code == 200
        assert resp.json() == []


@allure.feature("Получение объявлений продавца")
@allure.story("Валидация входных данных")
@allure.title("TC-203: Неверный формат sellerID")
@allure.severity(allure.severity_level.NORMAL)
def test_tc_203_invalid_seller_id(base_url):
    with allure.step("1. GET запрос с невалидным sellerID='abc'"):
        resp = requests.get(f"{base_url}/api/1/abc/item", timeout=30)

    with allure.step("2. Проверка статуса 400"):
        assert resp.status_code == 400


# STATISTICS


@allure.feature("Статистика объявлений")
@allure.story("API v1")
@allure.title("TC-301: Успешное получение статистики (v1)")
@allure.severity(allure.severity_level.NORMAL)
def test_tc_301_stat_v1(base_url):
    payload = {
        "sellerID": generate_seller_id(),
        "name": "Item",
        "price": 100,
        "statistics": {"likes": 5, "viewCount": 3, "contacts": 2},
    }

    with allure.step("1. Создание объявления"):
        _, item_id = create_item(payload, base_url)

    with allure.step("2. GET запрос на /api/1/statistic/{id}"):
        resp = requests.get(f"{base_url}/api/1/statistic/{item_id}", timeout=30)
        stats_list = resp.json()

    with allure.step("3. Проверка полей статистики"):
        assert resp.status_code == 200
        assert isinstance(stats_list, list)
        stats = stats_list[0]
        assert "likes" in stats
        assert "viewCount" in stats
        assert "contacts" in stats


@allure.feature("Статистика объявлений")
@allure.story("API v2")
@allure.title("TC-302: Успешное получение статистики (v2)")
@allure.severity(allure.severity_level.NORMAL)
def test_tc_302_stat_v2(base_url):
    payload = {
        "sellerID": generate_seller_id(),
        "name": "Item",
        "price": 100,
        "statistics": {"likes": 5, "viewCount": 3, "contacts": 2},
    }

    with allure.step("1. Создание объявления"):
        _, item_id = create_item(payload, base_url)

    with allure.step("2. GET запрос на /api/2/statistic/{id}"):
        resp = requests.get(f"{base_url}/api/2/statistic/{item_id}", timeout=30)
        stats_list = resp.json()

    with allure.step("3. Проверка полей статистики"):
        assert resp.status_code == 200
        assert isinstance(stats_list, list)
        stats = stats_list[0]
        assert "likes" in stats
        assert "viewCount" in stats
        assert "contacts" in stats


@allure.feature("Статистика объявлений")
@allure.story("Негативные сценарии")
@allure.title("TC-303: Получение статистики несуществующего объявления")
@allure.severity(allure.severity_level.NORMAL)
def test_tc_303_stat_not_found(base_url):
    fake_id = str(uuid.uuid4())

    with allure.step(f"1. GET /api/1/statistic/{fake_id}"):
        r1 = requests.get(f"{base_url}/api/1/statistic/{fake_id}", timeout=30)

    with allure.step(f"2. GET /api/2/statistic/{fake_id}"):
        r2 = requests.get(f"{base_url}/api/2/statistic/{fake_id}", timeout=30)

    with allure.step("3. Проверка: оба запроса возвращают 404"):
        assert r1.status_code == 404
        assert r2.status_code == 404


@allure.feature("Статистика объявлений")
@allure.story("Баг")
@allure.title("TC-304: Статистика удалённого объявления")
@allure.severity(allure.severity_level.MINOR)
@pytest.mark.e2e
@pytest.mark.xfail(reason="BUG-002: Статистика доступна для удалённого объявления")
def test_tc_304_stat_deleted_item(base_url):
    payload = {
        "sellerID": generate_seller_id(),
        "name": "Item",
        "price": 100,
        "statistics": {"likes": 1, "viewCount": 1, "contacts": 1},
    }

    with allure.step("1. Создание объявления"):
        _, item_id = create_item(payload, base_url)

    with allure.step("2. Удаление объявления"):
        delete_item(item_id, base_url)

    with allure.step("3. Запрос статистики удалённого объявления"):
        resp = requests.get(f"{base_url}/api/1/statistic/{item_id}", timeout=30)

    with allure.step("4. Ожидаем 404, но получаем 200 (баг)"):
        assert resp.status_code == 404
